=== BeAI ===
 
Contributors: softwarecraftpro
Tags: BeAI, image generator, content assistant, AI for WordPress
Requires at least: 6.0
Tested up to: 6.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
 
== Description ==
 
BeAI umożliwia generowanie grafik za pomocą sztucznej inteligencji (AI). Grafiki możesz generować za pomocą prompta lub na podstawie treści strony. Grafiki można zapisywać do biblioteki WordPress i ustawiać jako miniaturkę.
BeAI allows you to generate graphics using artificial intelligence (AI). You can generate graphics using a prompt or based on the page content. Images can be saved to the WordPress library and set as a thumbnail.
 
== Installation ==
 
1. Upload the plugin folder to your /wp-content/plugins/ folder.
1. Go to the **Plugins** page and activate the plugin.
 
== Frequently Asked Questions ==
 
= How do I use this plugin? =
 
W zakładce BeAI możesz skonfigurować wtyczkę oraz doładować tokeny, dzięki którym możesz generować obrazy. Obrazy można generować z poziomu każdego postu w sidebarze.
In the BeAI tab, you can configure the plugin and top up tokens with which you can generate images. Images can be generated from each post in the sidebar.
 
= How to uninstall the plugin? =
 
Simply deactivate and delete the plugin. 
 
== Screenshots ==
 
== Changelog ==
= 1.0 =
* Plugin released.