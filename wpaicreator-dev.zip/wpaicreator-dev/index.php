<?php

/**
 * @package BeAiCreator
 * @version 1.7.2
 */
/*
Plugin Name: BeAi.online
Plugin URI: http://wordpress.org/plugins/hello-dolly/
Description: BeAI allows you to generate graphics using artificial intelligence (AI). You can generate graphics using a prompt or based on the page content. Images can be saved to the WordPress library and set as a thumbnail.
Author: BeAi.online
Version: 1.0.0
Author URI: https://beai.online/,
*/

define( 'BEAI_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );

class BeAiCreator
{
    function __construct() {    
        include 'includes/init_menu.php';
        include 'includes/init_ui.php';
        include 'includes/init_scripts.php';
        include 'includes/init_functions.php';
    }

}

new BeAiCreator();

