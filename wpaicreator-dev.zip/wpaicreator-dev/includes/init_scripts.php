<?php


function beai_enqueue_scripts()
{


    wp_register_script('beai-creator-js', plugin_dir_url(__FILE__) . 'scripts/beai-creator.js', array('jquery'), '1.0', true);
    wp_enqueue_script('beai-creator-js');

    wp_register_script('beai-login-js', plugin_dir_url(__FILE__) . 'scripts/beai-login.js', array('jquery'), '1.0', true);
    wp_enqueue_script('beai-login-js');

    wp_register_script('beai-settings-js', plugin_dir_url(__FILE__) . 'scripts/beai-settings.js', array('jquery'), '1.0', true);
    wp_enqueue_script('beai-settings-js');

    wp_register_script('beai-alpine-js', plugin_dir_url(__FILE__) . 'scripts/beai-alpine.js', array('jquery'), '1.0', true);
    wp_enqueue_script('beai-alpine-js');


    // Rejestracja i dołączanie pliku CSS
    $css_files = ['global' => 'styles/global.css', 'ui' => 'styles/ui.css', 'settings' => 'styles/settings.css', 'menu' => 'styles/menu.css'];
    foreach ($css_files as $key => $path) {
        wp_register_style('beai-creator-css-' . $key, plugin_dir_url(__FILE__) . $path);
        wp_enqueue_style('beai-creator-css-' . $key);
    }
}
add_action('admin_enqueue_scripts', 'beai_enqueue_scripts');
