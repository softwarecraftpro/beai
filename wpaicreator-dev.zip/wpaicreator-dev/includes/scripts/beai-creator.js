function removeHtmlTags(html) {
    return html.replace(/(<([^>]+)>)/gi, '');
}

function removeCssRules(cssString) {
    const regex = /[^{]*{[^}]*}/g;
    return cssString.replace(regex, '');
}

const beaiGenerateImages = {
    url: 'https://admin.beai.online/api/generate',
    options: {},
    images: [],
    loader: false,
    imagePrompt: '',
    modalImageUrl: null,
    async getOptions() {
        const formData = new FormData();
        formData.append('action', 'beai_get_options');

        const res = await fetch(ajaxurl, {
            method: 'POST',
            body: formData,
        });

        const response = await res.json();

        if (response.data.options) {
            this.options = response.data.options;
        }

        return;
    },
    async generateImages() {
        this.loader = true;

        if (this.isInitialized) return;
        this.isInitialized = true;

        await this.getOptions();

        const size = this.options.images_size;
        const n = +this.options.images_per_request || 1;
        const additionalPrompt = this.options.images_prompt || '';

        const response = await fetch(`${this.url}/image`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.token,
            },
            body: JSON.stringify({ prompt: `${this.imagePrompt} ${additionalPrompt}`, n, size }),
        })
            .catch(() => {
                this.add({ type: 'error', text: 'Coś poszło nie tak podczas generowania obrazu.' });
            })
            .finally(() => {
                this.loader = false;
                this.isInitialized = false;
            });
        const res = await response.json();

        if (res.status === 'success') {
            this.add({ type: 'success', text: 'Obrazy zostały wygenerowane poprawnie.' });
        }

        if (res.status === 'error') {
            if (res.result === 'Not enough tokens') {
                this.add({ type: 'error', text: 'Brak środków na koncie. Doładuj saldo.' });

                return;
            }

            this.add({ type: 'error', text: res.result });

            return;
        }

        this.images = [...res.result.images, ...this.images];

        this.loader = false;
    },
    async saveImage(url, postId, setAsThumbnail) {
        if (this.isInitialized) return;
        this.isInitialized = true;

        this.loader = true;
        await this.getOptions();

        let formData = new FormData();
        formData.append('action', 'beai_add_image_to_gallery');

        if (setAsThumbnail) {
            const width = this.options.images_width;
            const height = this.options.images_height;
            if (width) formData.append('width', width);
            if (height) formData.append('height', height);

            formData.append('url', url);
            fetch(ajaxurl, {
                method: 'POST',
                body: formData,
            })
                .then((res) => res.json())
                .then((res) => {
                    this.setPostThumbnail(res.data.attachment_id, postId);
                });
        }

        const formData2 = new FormData();

        // const [width, height] = this.options.images_size.split('x');
        // if (width) formData2.append('width', width);
        // if (height) formData2.append('height', height);

        formData2.append('url', url);
        formData2.append('action', 'beai_add_image_to_gallery');

        fetch(ajaxurl, {
            method: 'POST',
            body: formData2,
        })
            .then((res) => res.json())
            .then((res) => {
                if (res.success) {
                    this.add({
                        type: 'success',
                        text: 'Grafika została zapisana poprawnie.',
                    });
                }
            })
            .finally(() => {
                this.loader = false;
                this.isInitialized = false;

                if (postId) return;
            });
    },
    openImageInModal(url) {
        if (this.modalImageUrl) return;
        this.modalImageUrl = url;

        const clonedNode = document.querySelector('.image-modal')?.cloneNode(true);

        if (!clonedNode) return;

        const img = clonedNode.querySelector('img');
        const closeBtn = clonedNode.querySelector('button');

        img.src = url;
        img.setAttribute('alt', this.imagePrompt);

        clonedNode.addEventListener('click', (e) => {
            if (e.target === e.currentTarget) {
                clonedNode.remove();
                this.modalImageUrl = null;
            }
        });

        closeBtn.addEventListener('click', () => {
            clonedNode.remove();
            this.modalImageUrl = null;
        });

        clonedNode.style.display = 'flex';

        document.body.appendChild(clonedNode);
    },
};

const mockImage = {
    url: 'https://fastly.picsum.photos/id/350/200/300.jpg?hmac=lAscVz0d1YWlAi5moOrwmJ0E7KNtxtLyHkE2pq3qnh8',
};

let isInitialized;

const notices = {
    notices: [],
    add(notice) {
        const id = Date.now();
        this.notices.push({ ...notice, id });

        const timeShown = 15_000;

        setTimeout(() => {
            this.remove(id);
        }, timeShown);
    },

    remove(id) {
        const notice = this.notices.find((notice) => notice.id == id);
        const index = this.notices.indexOf(notice);
        this.notices.splice(index, 1);
    },
};

function app({ token }) {
    const URL = 'https://admin.beai.online';

    return {
        prompt: '',
        title: '',
        description: '',
        image_url: '',
        token,
        ...notices,

        async getContent() {
            const el = document.querySelector('.editor-styles-wrapper');
            let text = removeHtmlTags(el.innerHTML);
            text = removeCssRules(text);

            this.generatePrompt(text);
        },
        async generatePrompt(text) {
            this.loader = true;
            if (this.isInitialized) return;
            this.isInitialized = true;

            await this.getOptions();

            const formData = new FormData();

            const size = this.options.prompt_images_size;
            const n = +this.options.prompt_images_per_request || 1;
            const additionalPrompt = this.options.prompt_images_prompt || '';
            const promptBase = this.options.prompt_images_prompt_text || '';

            const prompt = `${
                promptBase.includes('{text}') ? promptBase.replace('{text}', `"${text}"`) : text
            } ${additionalPrompt}`;

            formData.append('n', n);
            formData.append('prompt', prompt);
            formData.append('size', size);

            const response = await fetch(`${this.url}/prompt`, {
                method: 'POST',
                headers: {
                    Authorization: 'Bearer ' + this.token,
                },
                body: formData,
            })
                .catch(() => {
                    this.add({
                        type: 'success',
                        text: 'Coś poszło nie tak podczas generowania prompta i obrazów.',
                    });
                })
                .finally(() => {
                    this.loader = false;
                    this.isInitialized = false;
                });
            const res = await response.json();

            if (res.status === 'success') {
                this.add({
                    type: 'success',
                    text: 'Prompt i obrazy zostały wygenerowane poprawnie.',
                });
            } else if (res.status === 'error') {
                if (res.result === 'Not enough tokens') {
                    this.add({ type: 'error', text: 'Brak środków na koncie. Doładuj saldo.' });
                    this.loader;
                    return;
                }

                this.add({
                    type: 'error',
                    text: 'Coś poszło nie tak podczas generowania prompta i obrazów.',
                });
                return;
            }

            const firstResult = res.result.images[0];

            if (firstResult) {
                this.images = [...res.result.images, ...this.images];
                this.imagePrompt = firstResult.revisedPrompt;
            }
        },
        async setPostThumbnail(mediaId, postId) {
            this.loader = true;

            let formData = new FormData();
            formData.append('action', 'beai_set_post_thumbnail');

            await this.getOptions();

            formData.append('media_id', mediaId);
            formData.append('post_id', postId);

            fetch(ajaxurl, {
                method: 'POST',
                body: formData,
            })
                .then((res) => {
                    return res.json();
                })
                .then((res) => {
                    if (res.success) {
                        this.add({ type: 'success', text: 'Miniaturka została ustawiona poprawnie.' });
                    }
                })
                .finally(() => {
                    this.loader = false;
                    this.isInitialized = false;
                });
        },

        ...beaiGenerateImages,
    };
}
