function loginForm(url) {
    const URL = 'https://admin.beai.online';
    return {
        url,
        email: '',
        password: '',
        errors: [],
        validate() {
            this.errors = [];

            // Email validation
            if (!/\S+@\S+\.\S+/.test(this.email)) {
                this.errors.push('Zły format email.');
            }

            // Password validation
            if (this.password.length < 6) {
                this.errors.push('Hasło musi mieć conajmniej 6 znaków.');
            }

            return this.errors.length === 0;
        },
        async submit() {
            if (!this.validate()) return;

            const formData = new FormData();

            formData.append('email', this.email);
            formData.append('password', this.password);

            const response = await fetch(`${URL}/api/register`, {
                method: 'POST',
                body: formData,
            })
                // .catch(() => {
                //     this.errors.push('Wystąpił błąd podczas logowanie.');
                // })
                .finally(() => {
                    this.loader = false;
                    this.isInitialized = false;
                });

            const res = await response.json();

            if (res.success) this.login();

            if (res.error === 'User already exists') this.login();
        },
        async login() {
            const formData = new FormData();

            formData.append('username', this.email);
            formData.append('password', this.password);
            // formData.append('username', 'w.chudek@gloo.pl');
            // formData.append('password', 'Qwerty8*');
            formData.append('grant_type', 'password');
            formData.append('client_id', '2');
            formData.append('client_secret', 'aq4bjCeH6QNaiGhlBW6C8PVEPF0SBjSAYqTGdFdL');

            const response = await fetch(`${URL}/oauth/token`, {
                method: 'POST',
                body: formData,
            })
                .catch((err) => {
                    this.errors.push('Wystąpił błąd podczas logowania.');
                })
                .finally(() => {
                    this.loader = false;
                    this.isInitialized = false;
                });

            const res = await response.json();

            if (res.error) {
                this.errors.push('Podane dane są błędne.');
            }

            if (res.access_token) {
                this.saveToken(res.access_token);
            }
        },
        saveToken(token) {
            const formData = new FormData();
            formData.append('action', 'beai_save_token');

            formData.append('access_token', token);

            formData.append('url', url);

            fetch(ajaxurl, {
                method: 'POST',
                body: formData,
            }).then(() => {
                window.location.reload();
            });
        },
    };
}
