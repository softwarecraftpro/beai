const URL_API = 'https://admin.beai.online';

const BeaiDictionary = {
    company_name: 'Pole nazwy firmy jest wymagane, gdy nie podano imienia',
    first_name: 'Pole Imię jest wymagane',
    last_name: 'Pole Nazwisko jest wymagane',
    nip: 'Pole NIP jest wymagane',
    street: 'Pole Ulica i numer jest wymagane',
    city: 'Pole Miasto jest wymagane',
    postal_code: 'Pole Kod pocztowy jest wymagane',
    country: 'Pole Kraj jest wymagane',
    operation_amount: 'Pole Kwota jest wymagane',
};

const BeaiBillingDictionary = {
    'The company name field is required when first name is not present.':
        'Pole nazwy firmy jest wymagane, gdy nie podano imienia.',
    'The street field is required.': 'Pole ulicy jest wymagane.',
    'The city field is required.': 'Pole miasta jest wymagane.',
    'The postal code field is required.': 'Pole kodu pocztowego jest wymagane.',
    'The country field is required.': 'Pole kraju jest wymagane.',
};

function settingsPage({ token, wp_user }) {
    const URL = 'https://admin.beai.online';

    return {
        ...notices,
        // notices: [{ type: 'success', text: 'Coś poszło nie tak podczas generowania prompta i obrazów.', id: 0 }],
        openTab: 'generate', // generate, settings, pricing
        data: {
            company_name: '',
            first_name: '',
            last_name: '',
            nip: '',
            postal_code: '',
            city: '',
            street: '',
            country: '',
        },
        username: '',
        transactions: [],
        tokens: 0,
        token,
        billingErrors: [],
        errors: [],
        purchaseData: {
            operation_amount: 0,
            message: '',
            wp_user,
            redirect_url: window.location.href,
        },
        BeaiBillingDictionary,
        changeOpenTab(name) {
            let currentUrl = window.location.href;

            if (currentUrl.includes('#')) {
                currentUrl = currentUrl.replace(/#.*$/, `#${name}`);
            } else {
                currentUrl += `#${name}`;
            }

            window.location.href = currentUrl;

            this.openTab = name;
        },
        isOpenTab(name) {
            return name === this.openTab;
        },
        async getProfile() {
            if (window.location.href.includes('#pricing')) {
                this.changeOpenTab('pricing');
            }

            if (window.location.href.includes('#settings')) {
                this.changeOpenTab('settings');
            }

            const response = await fetch(`${URL_API}/api/profile`, {
                method: 'GET',
                headers: {
                    Authorization: 'Bearer ' + this.token,
                },
            });

            const res = await response.json();

            if (res.success) {
                this.username = res.data.email;
                this.transactions = res.data.transactions;
                this.tokens = res.data.current_tokens;

                if (res.data.billing) this.data = res.data.billing;
            }
        },
        async updateBillingData() {
            this.billingErrors = [];
            const formData = new FormData();

            for (key in this.data) {
                formData.append(key, this.data[key]);
            }

            const response = await fetch(`${URL}/api/profile/update`, {
                method: 'POST',
                body: formData,
                headers: {
                    Authorization: 'Bearer ' + this.token,
                },
            })
                .catch(() => {
                    this.add({ type: 'error', text: 'Wystąpił błąd podczas zakupu tokenów.' });
                })
                .finally(() => {
                    this.errors = [];
                });

            const res = await response.json();

            if (res.error) {
                this.billingErrors = Object.values(res.error).flat();
            }

            if (res.success) {
                this.add({ type: 'success', text: 'Dany zostały pomyślnie zaktualizowane.' });
            }
        },
        async purchase() {
            this.errors = [];

            const { company_name, first_name, last_name, nip, postal_code, city, street, country } = this.data;

            if (!company_name && !first_name && !last_name && !nip && !postal_code && !city && !street && !country) {
                this.add({ type: 'warning', text: 'Dane billingowe są niepoprawnie wypełnione' });

                return;
            }

            const data = { ...this.data, operation_amount: this.purchaseData.operation_amount };

            const formData = new FormData();

            for (key in data) {
                if (!data[key]) {
                    this.add({ type: 'warning', text: BeaiDictionary[key] || key });
                    return;
                }

                formData.append(key, data[key]);
            }
            formData.append('message', this.purchaseData.message);
            formData.append('wp_user', this.purchaseData.wp_user);
            formData.append('redirect_url', this.purchaseData.redirect_url);

            if (this.purchaseData.operation_amount < 30) {
                this.add({ type: 'warning', text: 'Kwota zakupu nie może być mniejsza niż 30zł' });

                return;
            }

            if (this.errors.length) return;

            const response = await fetch(`${URL}/api/createOrder`, {
                method: 'POST',
                body: formData,
                headers: {
                    Authorization: 'Bearer ' + this.token,
                },
            })
                .catch(() => {
                    this.add({ type: 'error', text: 'Wystąpił błąd podczas zakupu tokenów.' });
                })
                .finally(() => {
                    this.errors = [];
                });

            const res = await response.json();

            if (res.payment_url) {
                window.location = res.payment_url;
            } else {
                this.add({ type: 'error', text: 'Wystąpił błąd podczas zakupu tokenów.' });
            }
        },
        logout() {
            const formData = new FormData();
            formData.append('action', 'beai_save_token');

            formData.append('access_token', '');

            fetch(ajaxurl, {
                method: 'POST',
                body: formData,
            });

            setTimeout(() => {
                window.location.reload();
            }, 1000);
        },
        formatDate(dateString) {
            const originalDate = new Date(dateString);

            const formattedDate = `${('0' + originalDate.getDate()).slice(-2)}.${(
                '0' +
                (originalDate.getMonth() + 1)
            ).slice(-2)}.${originalDate.getFullYear()} ${('0' + originalDate.getHours()).slice(-2)}:${(
                '0' + originalDate.getMinutes()
            ).slice(-2)}`;

            return formattedDate;
        },
        ...beaiGenerateImages,
    };
}
