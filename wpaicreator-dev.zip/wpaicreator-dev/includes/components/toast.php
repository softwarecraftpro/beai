<div
    class="toast-container"
    style="pointer-events:none">
    <template x-for="notice of notices" :key="notice.id">
        <div
            @click="remove(notice.id)"
            class="toast"
            :class="{
                'toast-success': notice.type === 'success',
                'toast-info': notice.type === 'info',
                'toast-warning': notice.type === 'warning',
                'toast-error': notice.type === 'error',
            }"
            x-text="notice.text">
        </div>
    </template>
</div>







