<?php 
function beai_compress($source, $destination, $quality) {

    $info = getimagesize($source);

    if ($info['mime'] == 'image/jpeg') 
        $image = imagecreatefromjpeg($source);

    elseif ($info['mime'] == 'image/gif') 
        $image = imagecreatefromgif($source);

    elseif ($info['mime'] == 'image/png') 
        $image = imagecreatefrompng($source);

    imagejpeg($image, $destination, $quality);

    return $destination;
}

add_action('wp_ajax_beai_add_image_to_gallery', 'beai_add_image_to_gallery');
add_action('wp_ajax_nopriv_beai_add_image_to_gallery', 'beai_add_image_to_gallery');

function beai_add_image_to_gallery()
{
    $image_url = $_POST['url'];
    $image_width = isset($_POST['width']) ? $_POST['width'] : 0;
    $image_height = isset($_POST['height']) ? $_POST['height'] : 0;

    $image_data = file_get_contents($image_url);

    $filename = basename($image_url);


    $filename =  random_string(8) . ".png";

    $upload_dir = wp_upload_dir();

    $file_path = $upload_dir['path'] . '/' . $filename;
    $new_file_path = $upload_dir['path'] . '/' . $filename;

    file_put_contents($new_file_path, $image_data);
    beai_compress($file_path, $new_file_path, 75);


    if( $image_width && $image_height) {
        $editor = wp_get_image_editor($new_file_path);
        if (!is_wp_error($editor)) {
            $editor->resize($image_width, $image_height, true); 
            $editor->save($new_file_path);
        }
    }


    $attachment = array(
        'guid'           => $upload_dir['url'] . '/' . $filename,
        'post_mime_type' => 'image/png',
        'post_title'     => preg_replace('/\.[^.]+$/', '', $filename),
        'post_content'   => '',
        'post_status'    => 'inherit'
    );

    $attachment_id = wp_insert_attachment($attachment, $new_file_path);

    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attachment_data = wp_generate_attachment_metadata($attachment_id, $new_file_path);
    wp_update_attachment_metadata($attachment_id, $attachment_data);


    wp_send_json_success(array('attachment_id' => $attachment_id));

    exit;

}


add_action('wp_ajax_beai_set_post_thumbnail', 'beai_set_post_thumbnail');
add_action('wp_ajax_nopriv_beai_set_post_thumbnail', 'beai_set_post_thumbnail');

function beai_set_post_thumbnail()
{
    // Pobierz zawartość obrazu z URL-a
    $media_id = $_POST['media_id'];
    $post_id = $_POST['post_id'];
    $res = set_post_thumbnail( $post_id,  $media_id );

    $thumbnail_html = get_the_post_thumbnail($post_id);


    wp_send_json_success(array('thumbnail_html' => $thumbnail_html, 'res' => $res));

    die();
}

add_action('wp_ajax_beai_save_token', 'beai_save_token');
add_action('wp_ajax_nopriv_beai_save_token', 'beai_save_token');

function beai_save_token()
{
    $access_token = isset($_POST['access_token']) ? $_POST['access_token'] : '';
        
    update_option('beai_access_token', $access_token);

}


add_action('wp_ajax_beai_get_options', 'beai_get_options');
add_action('wp_ajax_nopriv_beai_get_options', 'beai_get_options');

function beai_get_options()
{
    $options = [
        'images_per_request' => get_option('beai_images_per_request'),
        'images_size' => get_option('beai_images_size'),
        'images_width' => get_option('beai_images_width'),
        'images_height' => get_option('beai_images_height'),
        'images_prompt' => get_option('beai_images_prompt'),
        'prompt_images_per_request' => get_option('beai_prompt_images_per_request'),
        'prompt_images_size' => get_option('beai_prompt_images_size'),
        'prompt_images_width' => get_option('beai_prompt_images_width'),
        'prompt_images_height' => get_option('beai_prompt_images_height'),
        'prompt_images_prompt_text' => get_option('beai_prompt_images_prompt_text'),
        'prompt_images_prompt' => get_option('beai_prompt_images_prompt'),
    ];


    wp_send_json_success(array('options' => $options));


    die();

}








function random_string($length)
{
    $key = '';
    $keys = array_merge(range(0, 9), range('a', 'z'));

    for ($i = 0; $i < $length; $i++) {
        $key .= $keys[array_rand($keys)];
    }

    return $key;
}
