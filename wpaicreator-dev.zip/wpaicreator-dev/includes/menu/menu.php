<?php

function beai_menu_page()
{
    $token = get_option("beai_access_token");

?>
    <div class="beai-wrapper">
        <div class="wrap beai">
            <h1>
            
        <?php  
            include( BEAI_PLUGIN_PATH . 'includes/assets/logo.php');
        ?>    
            </h1>


            <?php

            if(!$token)
            {
            ?>

            <div >
                <?php
                    include 'menu_login.php';

                ?>
            </div>

            <?php
            }
            ?>

        </div>

        <?php

        if($token)
        {
            ?>
            <div>
                <?php
                    include 'menu_settings.php';
                ?>
            </div>
        <?php
        }
        ?>


       
        
        </div>


    </div>
<?php
}

// Dodanie pól ustawień
function beai_settings_fields()
{
    add_settings_field('beai_access_token', 'Token', 'beai_empty_fn', 'beai-creator');

    add_settings_field('beai_images_per_request', 'Ilość zdjęć na zapytanie', 'beai_empty_fn', 'beai-creator');
    add_settings_field('beai_images_size', 'Rozmiar generowanych obrazów', 'beai_empty_fn', 'beai-creator');
    add_settings_field('beai_images_width', 'Rozmiar miniatur szerokość', 'beai_empty_fn', 'beai-creator');
    add_settings_field('beai_images_height', 'Rozmiar miniatur wysokość', 'beai_empty_fn', 'beai-creator');
    add_settings_field('beai_images_prompt', 'Atrybuty, które powinny zawierać grafiki', 'beai_empty_fn', 'beai-creator');

    add_settings_field('beai_prompt_images_per_request', 'Ilość zdjęć na zapytanie', 'beai_empty_fn', 'beai-creator');
    add_settings_field('beai_prompt_images_size', 'Rozmiar generowanych obrazów', 'beai_empty_fn', 'beai-creator');
    add_settings_field('beai_prompt_images_prompt_text', 'Atrybuty, które powinny zawierać grafiki', 'beai_empty_fn', 'beai-creator');
    add_settings_field('beai_prompt_images_prompt', 'Atrybuty, które powinny zawierać grafiki', 'beai_empty_fn', 'beai-creator');


}
add_action('admin_init', 'beai_settings_fields');


// Rejestracja ustawień
function beai_register_settings()
{
    register_setting('beai_auth_group', 'beai_access_token');

    register_setting('beai_settings_group', 'beai_images_width');
    register_setting('beai_settings_group', 'beai_images_height');
    
    register_setting('beai_settings_group', 'beai_images_per_request');
    register_setting('beai_settings_group', 'beai_images_size');
    register_setting('beai_settings_group', 'beai_images_prompt');

    register_setting('beai_settings_group', 'beai_prompt_images_per_request');
    register_setting('beai_settings_group', 'beai_prompt_images_size');
    register_setting('beai_settings_group', 'beai_prompt_images_prompt_text');
    register_setting('beai_settings_group', 'beai_prompt_images_prompt');
}
add_action('admin_init', 'beai_register_settings');

function beai_empty_fn()
{
}
