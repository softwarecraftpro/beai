<?php
$token = get_option("beai_access_token") ;
$user = wp_get_current_user();



?>
    <div class="beai beai-settings" x-data="settingsPage({ token: '<?= $token ?>', wp_user: '<?= $user->display_name ?>' })" x-init="getProfile()" @beaiauth.window="setToken">
        <div class="beai-nav">
            <div>
                <h1>BeAI</h1>
                <button :class="{'active': isOpenTab('generate')}" href="" x-on:click="changeOpenTab('generate')">Generuj</button>
                <button :class="{'active': isOpenTab('settings')}" href="" x-on:click="changeOpenTab('settings')">Ustawienia</button>
                <button :class="{'active': isOpenTab('pricing')}" x-on:click="changeOpenTab('pricing')">Twoje saldo: <span x-text="tokens"></span> tokenów</button>
            </div>

            <div>
                <p x-text="username"></p>
                <button x-on:click="logout">WYLOGUJ SIĘ</button>
            </div>
        </div>


        <div x-cloak x-show="isOpenTab('generate')" >
            <?php
            include 'settings/settings_generate.php';
            ?>
        </div>

        <div x-cloak x-show="isOpenTab('settings')" >
            <?php
            include 'settings/settings_general.php';
            ?>
        </div>

        <div x-cloak x-show="isOpenTab('pricing')">
            <?php
            include 'settings/settings_pricing.php';
            ?>
        </div>
        

        <?php  
            include( BEAI_PLUGIN_PATH . 'includes/components/toast.php');
        ?>
    </div>

        
<?php



