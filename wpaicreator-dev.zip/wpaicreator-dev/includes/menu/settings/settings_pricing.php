<?php
    $first_name = get_option('beai_first_name');
    $last_name = get_option('beai_last_name');
    $nip = get_option('beai_nip');
    $street = get_option('beai_street');
    $city = get_option('beai_city');
    $postal_code = get_option('beai_postal_code');
    $country = get_option('beai_country');

?>
    <div class="settings-grid">
        <div>
            <div>
                <div class="settings-header">
                    DANE BILLINGOWE
                </div>
                <div class="form form--full" action="">
            <div class="form-field">
                        <label>Nazwa firmy </label>
                        <input x-model="data.company_name" type="text">
                    </div>

                    <div class="form-field">
                        <label>Imie </label>
                        <input x-model="data.first_name" type="text">
                    </div>

                    <div class="form-field">
                        <label>Nazwisko </label>
                        <input x-model="data.last_name" type="text">
                    </div>


                    <div class="form-field">
                        <label>Ulica i numer</label>
                        <input x-model="data.street"  type="text">
                    </div>


                    <div class="form-field">
                        <label>Miasto</label>
                        <input x-model="data.city"  type="text">
                    </div>

                    <div class="form-field">
                        <label>Kod pocztowy</label>
                        <input x-model="data.postal_code"  type="text">
                    </div>


                    <div class="form-field">
                        <label>Kraj</label>
                        <input x-model="data.country"  type="text">
                    </div>

                    <div class="form-field">
                        <label>NIP</label>
                        <input x-model="data.nip"  type="text">
                    </div>

                    <button class="btn" x-on:click="updateBillingData()">Zapisz</button>

                    <ul class="beai-errors">
                        <template x-for="error in billingErrors" :key="error">
                            <li class="beai-error" x-text="BeaiBillingDictionary[error] || error"></li>
                        </template>
                    </ul>
                </div>
            </div>
        </div>

        <div>
            <div>
                <div class="settings-header">
                    DOŁADUJ SALDO
                </div>

                <div class="purchasing-balance">
                    <div class="form-field">
                        <label>Kwota doładowania </label>
                        <p>(min. 30 pln)</p>
                        <input x-model="purchaseData.operation_amount"  min="30" type="number">
                    </div>

                    <div class="form-field">
                        <label>Dodatkowe informacje</label>
                        <textarea x-model="purchaseData.message" ></textarea>
                    </div>

                    <button type="button" x-on:click="purchase()" class="btn">Kup teraz</button>

                    <ul class="beai-errors">
                            <template x-for="error in errors" :key="error">
                                <li class="beai-error" x-text="error"></li>
                            </template>
                        </ul>
                </div>
            </div>
        </div>

        <div>
            <div>
                <div class="settings-header">
                    HISTORIA SALDA
                </div>
                <div class="purchasing-table">
                    <div class="purchasing-table-head">
                        <div>Data i czas</div>
                        <div>Użytkownik</div>
                        <div>
                            Ilość tokenów
                        </div>
                        <div>
                            Ilość złotych
                        </div>
                    </div>
                    <div>
                        <ul>
                            <template x-for="item in transactions" >
                                <li>
                                    <div x-text="item.created_at ? formatDate(item.created_at) : '-'"></div>
                                    <div x-text="item.wp_user || '-'"></div>
                                    <div :class="item.type" x-text="item.operation_amount || '-'"></div>
                                    <div :class="item.type" x-text="(+item.cost).toFixed(2) || '-'"></div>

                                </li>
                            </template>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php
