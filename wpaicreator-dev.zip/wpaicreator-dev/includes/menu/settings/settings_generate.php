<?php
    $first_name = get_option('beai_first_name');
    $last_name = get_option('beai_last_name');
    $nip = get_option('beai_nip');
    $street = get_option('beai_street');
    $city = get_option('beai_city');
    $postal_code = get_option('beai_postal_code');
    $country = get_option('beai_country');

?>
    <div class="settings-grid">
   

        <div>
            <div>
                <div class="settings-header">
                    WYGENERUJ OBRAZ
                </div>
                <div class="form form--full" >
                    <div class="form-field">
                        <p>Podaj treść prompta (polecenia) co powinien przedstawiać obraz. </p>
                        <textarea x-model="imagePrompt" type="text"></textarea>
                    </div>

                    <button type="button" x-on:click="generateImages" class="btn" :class="{    
                     'btn--disabled': imagePrompt === ''
                    }">Generuj obraz</button>
                </div>
            </div>


        </div>

        <div class="settings-generate-images">
            <div>
                <div class="settings-header">
                    WYGENEROWANE OBRAZY
                </div>

                <div class="form form--full" >
                    <ul class="beai-images">
                        <template x-for="image in images" :key="image.url">
                            <li>
                                <img :src="image.url" alt="" width="300" height="300" x-on:click="openImageInModal(image.url)">
                                <div class="buttons">
                                    <button type="button" x-on:click="saveImage(image.url)" class="btn btn--full">Zapisz w galerii</button>
                                </div>
                            </li>
                        </template>
                    </ul>
                </div>

           
            </div>

        </div>

        <template x-if="loader">
            <div class="loader">
                <span class="spinner"></span>
            </div>
        </template>

   
    </div>
    
            <div  style="display: none" class="image-modal" >
                <button aria-label="Zamknij modal"></button>
                <img  >
        </div>
<?php
