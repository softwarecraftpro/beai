<?php
    $images_per_request = get_option('beai_images_per_request');
    $images_size = get_option('beai_images_size');
    $images_width = get_option('beai_images_width');
    $images_height = get_option('beai_images_height');
    $images_prompt = get_option('beai_images_prompt');

    $prompt_images_per_request = get_option('beai_prompt_images_per_request');
    $prompt_images_size = get_option('beai_prompt_images_size');
    $prompt_images_prompt_text = get_option('beai_prompt_images_prompt_text');
    $prompt_images_prompt = get_option('beai_prompt_images_prompt');

    $sizes = ['1024x1024', '1792x1024', '1024x1792'];


?>
    <form method="post" action="options.php#settings" class="settings-grid">
        <?php
        settings_fields('beai_settings_group');

        do_settings_sections('beai-creator');
        ?>


        <div>
            <div>
                <div class="settings-header">
                    PARAMETRY GENEROWANIA GRAFIK Z PROMPTA
                </div>
                <div class="form" action="">
                    <div class="form-field">
                        <label>Ilość generowanych grafik dla jednego zapytania</label>
                        <p>Min 1 - Max 4</p>
                        <input name="beai_images_per_request" value="<?= $images_per_request ?>" min="1" max="4" type="number">
                    </div>

                    <div class="form-field">
                        <label>Rozmiar generowanych obrazów</label>
                        <select name="beai_images_size" class="image-select">
                            <?php foreach ($sizes as $size) : ?>
                                <option class="image-option" <?= $images_size === $size ? 'selected="selected"' : '' ?> value="<?= $size ?>"><?= $size ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>



                    
                    <div class="form-field">
                        <label>Atrybuty, które powinny zawierać grafiki</label>
                        <p>Np. high quality, 4k, realistic, modern</p>
                        <textarea name="beai_images_prompt" value="<?= $images_width ?>" ><?= $images_prompt ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <div>
            <div>
                <div class="settings-header">
                    PARAMETRY GENEROWANIA GRAFIK Z TREŚCI STRONY
                </div>
                <div class="form" action="">
                    <div class="form-field">
                        <label>Ilość generowanych grafik dla jednego zapytania</label>
                        <p>Min 1 - Max 4</p>
                        <input name="beai_prompt_images_per_request" value="<?= $prompt_images_per_request ?>" min="1" max="4" type="number">
                    </div>

                    <div class="form-field">
                        <label>Rozmiar generowanych obrazów</label>
                        <select name="beai_prompt_images_size" class="image-select">
                            <?php foreach ($sizes as $size) : ?>
                                <option class="image-option" <?= $prompt_images_size === $size ? 'selected="selected"' : '' ?> value="<?= $size ?>"><?= $size ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>



                    <div class="form-field">
                        <label>Treść prompta do obróbki tekstu na prompt do wygenerowania grafik.</label>
                        <p><strong>{text}</strong> - zmienna zamieszczająca treść, z której powstanie prompt.</p>
                        <textarea name="beai_prompt_images_prompt_text"  ><?= $prompt_images_prompt_text ?></textarea>
                    </div>
                    
                    
                    <div class="form-field">
                        <label>Atrybuty, które powinny zawierać grafiki</label>
                        <p>Np. high quality, 4k, realistic, modern</p>
                        <textarea name="beai_prompt_images_prompt"  ><?= $prompt_images_prompt ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <div>
            <div>
                <div class="settings-header">
                    PARAMETRY ZAPISYWANIA GRAFIK
                </div>
                <div class="form" action="">
                    <div class="form-field">
                        <label>Rozmiar miniatur (px)</label>
                        <div class="input-grid">
                            <p>Szerokość</p>
                            <p>Wysokość</p>
                        </div>

                        <div class="input-grid">
                            <input name="beai_images_width" value="<?= $images_width ?>" type="number">
                            <input name="beai_images_height" value="<?= $images_height ?>" type="number">
                        </div>
                    </div>
                </div>
            </div>

            <button class="btn save-btn">Zapisz</button>
        </div>
    </form>
<?php
