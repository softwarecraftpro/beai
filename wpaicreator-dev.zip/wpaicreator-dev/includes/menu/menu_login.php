<?php
  $images_per_request = get_option('beai_images_per_request');

    if(!$images_per_request) {
        update_option('beai_images_per_request', 1);
    }

    $images_size = get_option('beai_images_size');
    if(!$images_size) {
        update_option('beai_images_size', '1024x1024');
    }


    $images_width = get_option('beai_images_width');
    if(!$images_width) {
        update_option('beai_images_width', 320);
    }

    $images_height = get_option('beai_images_height');
    if(!$images_height) {
        update_option('beai_images_height', 480);
    }

    $images_prompt = get_option('beai_images_prompt');
    if(!$images_prompt) {
        update_option('beai_images_prompt', '. Na grafice nie dodawaj żadnych napisów');
    }

    $prompt_images_per_request = get_option('beai_prompt_images_per_request');
    if(!$prompt_images_per_request){
        update_option('beai_prompt_images_per_request', 1);

    }

    $prompt_images_size = get_option('beai_prompt_images_size');
    if(!$prompt_images_size) {
        update_option('beai_prompt_images_size', '1024x1024');
    }



    $prompt_images_prompt = get_option('beai_prompt_images_prompt');
    if(!$prompt_images_prompt) {
        update_option('beai_prompt_images_prompt', '. Na grafice nie dodawaj żadnych napisów');
    }
    
    $prompt_images_prompt_text = get_option('beai_prompt_images_prompt_text');
    if(!$prompt_images_prompt_text) {
        update_option('beai_prompt_images_prompt_text', 'Wygeneruj grafikę abstrakcyjną, która interpretuje {text}, używając form, kolorów i tekstur do przedstawienia kluczowych pojęć i emocji zawartych w tekście. Obraz powinien pobudzać wyobraźnię widza, pozostawiając miejsce na indywidualną interpretację zawartych w nim idei.');
    }





$token = get_option("beai_access_token");
?>

<div class="wrap beai">
    <div class="beai-menu">
        <div class="beai-signin" x-data="loginForm({ url: '<?= get_option('beai_api_url') ?>' })">
            <div class="signin-header">
                BeAI
            </div>

            <div class="signin-body">
                <p>
                    Podaj adres e-mail i hasło, aby się zalogować i móc korzystać z wtyczki. Jeżeli nie posiadasz jeszcze konta, to zostanie ono automatycznie utworzone
                </p>

                <form method="post" >
                    <div>
                        <label>Adres e-mail</label>
                        <input type="email" x-model="email" />
                    </div>
                    
                    <div>
                        <label>Hasło</label>
                        <input type="password" x-model="password" />
                    </div>

                    <button type="button" class="btn" :class="{'btn--disabled': !email || !password}" x-on:click="submit">Zaloguj</button>

                    <ul class="beai-errors">
                        <template x-for="error in errors" :key="error">
                            <li class="beai-error" x-text="error"></li>
                        </template>
                    </ul>
                </form>
            </div>
        </div>
    </div>
</div>

