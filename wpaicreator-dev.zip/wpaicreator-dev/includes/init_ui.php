<?php


function beai_add_custom_box()
{
    $is_logged = true;
    
    $cpts = get_post_types(array('public' => true, '_builtin' => false), 'names', 'and');
    $post_types = array_merge($cpts, ['page', 'post', 'product']);

    $token = get_option("beai_access_token");


    foreach ($post_types as $post_type) {
        add_meta_box(
            'beai_box_id', 
            'BeAI',    
            $token ? 'beai_custom_box_html' : 'beai_custom_box_html_login',  
            $post_type,                
            'side'
        );
    }
}
add_action('add_meta_boxes', 'beai_add_custom_box');

function beai_custom_box_html_login()
{
?>
    <div class="beai">
        <div class="beai-login">
            <div class="title">Przejdź do ustawień wtyczki, aby się zalogować i zasilić saldo.</div>

            <a href="<?php echo admin_url('admin.php?page=beai-creator') ?>" class="btn">Zaloguj się</a>
        </div>
    </div>
<?php
}
?>
<?php
function beai_custom_box_html($post)
{


$token = get_option("beai_access_token");


?>
    <div x-data="app({
        url: '<?= get_option('beai_api_url') ?>',
        token: '<?= $token ?>',
        })" class="beai">

        <div>
            <template x-if="loader">
                <div class="loader">
                    <span class="spinner"></span>
                </div>
            </template>
        </div>

        <div>
            
            <div class="title">Wygeneruj obrazy</div>
            <div>
                <button type="button" x-on:click="getContent" class="btn btn--full">Wygeneruj obraz z treści</button>
            </div>

            <textarea placeholder="Lub wpisz treść prompta" x-model="imagePrompt"></textarea>

            <div class="generate-actions">
                <button type="button" x-on:click="generateImages" class="btn" :class="{    
                     'btn--disabled': imagePrompt === ''
                    }">Generuj obraz</button>
            </div>

            <div x-show="images.length" class="beai-images-wrapper">
                <div class="title">Wygenerowane obrazy</div>

                <ul class="beai-images">
                    <template x-for="image in images" :key="image.url">
                        <li>
                            <img :src="image.url" alt="" width="300" height="300" x-on:click="openImageInModal(image.url)">
                            <div class="buttons">
                                <button type="button" x-on:click="saveImage(image.url)" class="btn btn--full">Zapisz</button>
                                <button type="button" class="btn btn--full" x-on:click="saveImage(image.url, '<?=  get_the_ID() ?>', true)" >Miniaturka</button>
                            </div>
                        </li>
                    </template>
                </ul>
            </div>

          
        </div>



        <div  style="display: none" class="image-modal" >
                <button aria-label="Zamknij modal"></button>
                <img  >
        </div>

        <?php  
            include 'components/toast.php';
        ?>


    </div>

    
<?php
}
?>