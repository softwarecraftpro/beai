<?php


include 'menu/menu.php';

// include 'menu/settings/xd.php';

// Dodanie elementu w menu
function beai_add_menu()
{
    $is_logged = false;

    add_menu_page('BeAI', 'BeAI', 'manage_options', 'beai-creator', 'beai_menu_page', 'dashicons-buddicons-replies', 200);
}
add_action('admin_menu', 'beai_add_menu');


add_filter('plugin_action_links', 'beai_action_links', 10, 2);

function beai_action_links($links, $file) {
    // Check if it's your plugin file
        // Add Settings link
        $settings_link = '<a href="admin.php?page=beai-creator#settings">Settings</a>';
        array_push($links, $settings_link);
    return $links;
}
